//
//  DemoViewController.h
//  SampleApp
//
//  Created by Mist on 17/08/16.
//  Copyright © 2016 Mist. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoViewController : UIViewController{
    
    __weak IBOutlet UITableView *demoListTableView;
}

@end
