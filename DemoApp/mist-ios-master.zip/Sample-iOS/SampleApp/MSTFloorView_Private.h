//
//  MSTFloorView_Private.h
//  Mist
//
//  Created by Cuong Ta on 8/8/16.
//  Copyright © 2016 mist. All rights reserved.
//

#import "MSTFloorView.h"

@interface MSTFloorView ()

@property (nonatomic, assign) bool isAnimating;

@end
