//
//  VitrualBeaconViewController.h
//  SampleApp
//
//  Created by Mist on 19/08/16.
//  Copyright © 2016 Mist. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VitrualBeaconViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextView *vbnotificationtextView;
@property (strong, nonatomic) IBOutlet UITextView *zoneNotificationTextView;

@end
