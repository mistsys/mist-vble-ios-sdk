//
//  OrganizationPageViewController.h
//  SampleApp
//
//  Created by Mist on 17/08/16.
//  Copyright © 2016 Mist. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
@interface OrganizationPageViewController : UIViewController<CLLocationManagerDelegate>{
    
    __weak IBOutlet UITableView *orgTableView;
}

@end
